// import logo from '../logo.svg';

// import '../App.css';

// import { Switch, Route } from 'react-router-dom';
// import Home from '../Pages/Home/Home';
// import Aboutus from '../Pages/Aboutus/Aboutus';
// import MotorCycles from '../Pages/MotorCycles/MotorCycles';
// import NFT_Listed from '../Pages/NFT_Listed/NFT_Listed';
// import Login from '../Component/Auth/Login';
// import Signup from '../Component/Auth/Signup';
// import NFT_Campaign from '../Pages/NFT_Campaign/NFT_Campaign';
// import NFT_Sale from '../Pages/NFT_Sale/NFT_Sale';
// import Store from '../Pages/Store/Store';



// function RouteLink() {
//     return (
//         <>
//             <Switch>
//                 <Route exact path="/" component={Home} />
//                 <Route exact path="/aboutus" component={Aboutus} />
//                 <Route exact path="/MotorCycles" component={MotorCycles} />
//                 <Route exact path="/NFT_Listed" component={NFT_Listed} />
//                 <Route exact path="/Login" component={Login} />
//                 <Route exact path="/Signup" component={Signup} />
//                 <Route exact path="/NFT_Campaign" component={NFT_Campaign} />
//                 <Route exact path="/NFT_Sale" component={NFT_Sale} />
//                 <Route exact path="/Store" component={Store} />
//             </Switch>
//         </>
//     );
// }

// export default RouteLink;
